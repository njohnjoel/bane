add_5 = lambda number: number +12
print(add_5(12))
print(add_5(33))