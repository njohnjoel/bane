#variable 
#watch=500
#print(watch)

word1='Yello'
word4="My name is John"
print(word4.lower())
print(word4.capitalize())
print(word1.replace('Y','H')+" ," +word4)

fruits = ['Apple','Orange','Banana']
print(len(fruits))
fruits.sort(reverse=True)
print(fruits)

#Tuple
print(fruits.reverse())

#Dictionary Key & Values
my_data = {
    "name ": "Joel",
    "age": 36
}

print(my_data.get('age'))

#-------------------------------------------------------#

#If Statements
age = 19
print(age)

