name = input("Enter your name \n")
print("Hey "+name+" , Can code in python")

animal = "dog"
print(name+"'s Favourite animal is dog")
print("o-####-")
print("  |  | ")
print ("This is "+name +"'s little home")

print("  _|_          ")
print(" |   |")
print(" |___|______|")
print(" |   |      |")
print(" |___|______|")
print(" |_    |    |")
print("_|_|___|____| ")

age=int(input("Your birth Year ? \n"))
year=int(2040)
out=(year-age)
print("By",year,",", name, "will be ",out)