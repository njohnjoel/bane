for num in range(2):
    print(num)
    for h in range(2):
        print(h)
else: 
    print ('All numbers are finished')