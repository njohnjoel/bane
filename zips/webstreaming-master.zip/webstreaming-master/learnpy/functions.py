def multiply():
    a=23
    b=45
    print(a*b)

multiply()

#--------------------------------
def addition(a,b):
    print(a+b)

addition(12,15)
addition(100,112)


#--------------------------------
def hi(name):
    print("Welcome "+ name + ", How are you Today?")

hi("Balu")