#input function
#name = input("what is your name ? \n")
#print("Hello "+ name + " ,How are you today ?")

number1=int(input("Enter a Number here .. \n"))
number2=int(input(" Try Keeping it Smaller than Number_1 \n"))

print(number1*number2)
print(number1+number2)
print(number1-number2)
print(number1/number2)